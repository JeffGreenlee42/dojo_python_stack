
function changeBackgroundColor(elem, bcolor) {
    document.getElementsByClassName(elem).style.c = bcolor;
}

function changeTextColor(elem, color) {
    document.getElementsByClassName(elem).style.c = color;
}
